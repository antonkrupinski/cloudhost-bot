const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.slashCommands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'There was an error executing this command!', ephemeral: true });
            }
        } else if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'support_select') {
                if (interaction.values[0] === 'support') {
                    await handleSupportCreation(interaction);
                }
            } else if (interaction.customId === 'ticket_actions') {
                await handleTicketActions(interaction);
            }
        } else if (interaction.isButton()) {
            if (interaction.customId === 'close_ticket') {
                await handleCloseTicket(interaction);
            } else if (interaction.customId === 'claim_ticket') {
                await handleClaimTicket(interaction);
            } else if (interaction.customId === 'confirm_close_yes') {
                await handleConfirmClose(interaction, true);
            } else if (interaction.customId === 'confirm_close_no') {
                await handleConfirmClose(interaction, false);
            }
        }
    },
};

async function handleSupportCreation(interaction) {
    const guild = interaction.guild;
    const user = interaction.user;

    console.log('Creating support ticket for user:', user.id);

    // Check if user already has an open ticket
    const existingChannel = guild.channels.cache.find(channel =>
        channel.name === `ticket-${user.id}` && channel.parentId === '1453921299004133448'
    );

    if (existingChannel) {
        console.log('User already has an open ticket');
        return await interaction.reply({ content: 'You already have an open support ticket!', ephemeral: true });
    }

    try {
        // Create the ticket channel
        console.log('Creating ticket channel...');
        const ticketChannel = await guild.channels.create({
            name: `ticket-${user.id}`,
            type: ChannelType.GuildText,
            parent: '1453921299004133448',
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: [PermissionFlagsBits.ViewChannel],
                },
                {
                    id: user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                },
                {
                    id: '1448673842615681094', // Support role
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                },
            ],
        });

        console.log('Ticket channel created:', ticketChannel.id);

        // Create the ticket embed
        const embed = new EmbedBuilder()
            .setTitle('Support Ticket')
            .setDescription(`Ticket created by ${user}\n\nPlease describe your issue and wait for a support member to assist you.`)
            .setColor(0x2f6070)
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('ticket_actions')
                    .setPlaceholder('Ticket Actions')
                    .addOptions([
                        {
                            label: 'Close Ticket',
                            description: 'Close this support ticket',
                            value: 'close',
                        },
                        {
                            label: 'Claim Ticket',
                            description: 'Claim this ticket (Support only)',
                            value: 'claim',
                        },
                    ]),
            );

        console.log('Sending embed to ticket channel...');
        await ticketChannel.send({ embeds: [embed], components: [row] });
        console.log('Embed sent successfully');

        await interaction.reply({ content: `Support ticket created: ${ticketChannel}`, ephemeral: true });
    } catch (error) {
        console.error('Error creating support ticket:', error);
        await interaction.reply({ content: 'Failed to create support ticket. Please try again later.', ephemeral: true });
    }
}

async function handleTicketActions(interaction) {
    const action = interaction.values[0];
    const channel = interaction.channel;
    const user = interaction.user;

    if (action === 'close') {
        // Check if user is support or ticket owner
        const isSupport = interaction.member.roles.cache.has('1448673842615681094');
        const isOwner = channel.name === `ticket-${user.id}`;

        if (!isSupport && !isOwner) {
            return await interaction.reply({ content: 'You cannot close this ticket!', ephemeral: true });
        }

        if (isSupport) {
            // Support member closing - ask for confirmation
            const embed = new EmbedBuilder()
                .setTitle('Confirm Ticket Closure')
                .setDescription('Do you want to close this ticket?')
                .setColor(0xff0000);

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirm_close_yes')
                        .setLabel('Yes')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('confirm_close_no')
                        .setLabel('No')
                        .setStyle(ButtonStyle.Secondary),
                );

            await interaction.reply({ embeds: [embed], components: [row] });
        } else {
            // User closing - close immediately
            await interaction.reply({ content: 'Ticket will be closed in 10 seconds...', ephemeral: true });
            
            // Log the ticket before closing
            await logTicket(channel);
            
            setTimeout(async () => {
                await channel.delete();
            }, 10000);
        }
    } else if (action === 'claim') {
        // Only support can claim
        if (!interaction.member.roles.cache.has('1448673842615681094')) {
            return await interaction.reply({ content: 'Only support members can claim tickets!', ephemeral: true });
        }

        // Check if ticket is already claimed
        const ticketOwnerId = channel.name.replace('ticket-', '');
        const permissions = channel.permissionOverwrites.cache;
        const isClaimed = permissions.some(perm => 
            perm.id !== channel.guild.id && 
            perm.id !== '1448673842615681094' && 
            perm.id !== ticketOwnerId && 
            perm.allow.has(PermissionFlagsBits.SendMessages)
        );

        if (isClaimed) {
            return await interaction.reply({ content: 'This ticket is already claimed!', ephemeral: true });
        }

        // Claim the ticket
        await channel.send(`${user} has claimed this ticket!`);

        // Update permissions to only allow the claimant and ticket owner to speak
        await channel.permissionOverwrites.edit(channel.guild.id, { SendMessages: false });
        await channel.permissionOverwrites.edit(user.id, { SendMessages: true });
        await channel.permissionOverwrites.edit(ticketOwnerId, { SendMessages: true });

        await interaction.reply({ content: 'Ticket claimed successfully!', ephemeral: true });
    }
}

async function handleConfirmClose(interaction, confirm) {
    if (!interaction.member.roles.cache.has('1448673842615681094')) {
        return await interaction.reply({ content: 'Only support members can confirm ticket closure!', ephemeral: true });
    }

    if (confirm) {
        await interaction.reply({ content: 'Ticket closed!', ephemeral: true });
        
        // Log the ticket before closing
        await logTicket(interaction.channel);
        
        setTimeout(async () => {
            await interaction.channel.delete();
        }, 1000);
    } else {
        await interaction.reply({ content: 'Ticket closure cancelled.', ephemeral: true });
    }
}

async function logTicket(channel) {
    try {
        // Fetch all messages from the ticket channel
        const messages = await channel.messages.fetch({ limit: 100 });
        const sortedMessages = messages.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
        
        // Format messages
        let chatLog = '';
        for (const message of sortedMessages.values()) {
            const timestamp = message.createdAt.toLocaleString();
            const author = message.author.tag;
            const content = message.content || '[Embed/Attachment]';
            chatLog += `[${timestamp}] ${author}: ${content}\n`;
        }
        
        // If chat log is too long, truncate it
        if (chatLog.length > 4000) {
            chatLog = chatLog.substring(0, 4000) + '\n... (truncated)';
        }
        
        // Get ticket info
        const ticketOwnerId = channel.name.replace('ticket-', '');
        const ticketOwner = await channel.guild.members.fetch(ticketOwnerId).catch(() => null);
        const ownerName = ticketOwner ? ticketOwner.user.tag : 'Unknown';
        
        // Create log embed
        const logEmbed = new EmbedBuilder()
            .setTitle(`Ticket Closed: ${channel.name}`)
            .setDescription(`**Ticket Owner:** ${ownerName}\n**Closed At:** ${new Date().toLocaleString()}\n\n**Chat Log:**\n\`\`\`\n${chatLog}\`\`\``)
            .setColor(0xff0000)
            .setTimestamp();
        
        // Send to log channel
        const logChannel = channel.guild.channels.cache.get('1448923462797103198');
        if (logChannel) {
            await logChannel.send({ embeds: [logEmbed] });
        }
    } catch (error) {
        console.error('Error logging ticket:', error);
    }
}