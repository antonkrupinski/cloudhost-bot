const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const fs = require('fs');
const path = require('path');

module.exports = async (client) => {
    const commands = [];
    const commandFiles = fs.readdirSync(path.join(__dirname, '../slashCommands')).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        const command = require(`../slashCommands/${file}`);
        commands.push(command.data.toJSON());
        client.slashCommands.set(command.data.name, command);
    }

    const rest = new REST({ version: '9' }).setToken(client.config.TOKEN);

    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands(client.config.CLIENTID),
            { body: commands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
};