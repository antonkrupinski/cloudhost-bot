const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    const loadEvents = (dir) => {
        const eventFiles = fs.readdirSync(dir);

        for (const file of eventFiles) {
            const filePath = path.join(dir, file);
            const stat = fs.statSync(filePath);

            if (stat.isDirectory()) {
                loadEvents(filePath);
            } else if (file.endsWith('.js')) {
                const event = require(filePath);
                if (event.name) {
                    if (event.once) {
                        client.once(event.name, (...args) => event.execute(...args));
                    } else {
                        client.on(event.name, (...args) => event.execute(...args));
                    }
                    console.log(`Loaded event: ${event.name}`);
                }
            }
        }
    };

    loadEvents(path.join(__dirname, '../events'));
};