const { SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-user')
        .setDescription('Add a user to the allowed list (Owner only)')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to add')
                .setRequired(true)),

    async execute(interaction) {
        // Check if the user is the owner
        if (interaction.user.id !== '1045370637776064612') {
            return await interaction.reply({ content: 'You do not have permission to use this command!', ephemeral: true });
        }

        const user = interaction.options.getUser('user');

        // Path to users.json
        const usersPath = path.join(__dirname, '../../config/users.json');

        // Read or create users list
        let users = [];
        if (fs.existsSync(usersPath)) {
            users = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
        }

        // Check if user is already added
        if (users.includes(user.id)) {
            return await interaction.reply({ content: `${user.username} is already in the allowed list!`, ephemeral: true });
        }

        // Add user
        users.push(user.id);

        // Write back
        fs.writeFileSync(usersPath, JSON.stringify(users, null, 4));

        // Reply
        await interaction.reply({ content: `Successfully added ${user.username} to the allowed list!`, ephemeral: true });
    },
};