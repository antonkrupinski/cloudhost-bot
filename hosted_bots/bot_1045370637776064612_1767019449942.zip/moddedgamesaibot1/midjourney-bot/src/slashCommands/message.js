const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('message')
        .setDescription('Send a message as the bot (Owner only)')
        .addStringOption(option =>
            option.setName('text')
                .setDescription('The message to send')
                .setRequired(true)),

    async execute(interaction) {
        // Check if the user is the owner
        if (interaction.user.id !== '1045370637776064612') {
            return await interaction.reply({ content: 'You do not have permission to use this command!', ephemeral: true });
        }

        const text = interaction.options.getString('text');

        // Send the message
        await interaction.channel.send(text);

        // Reply to the interaction
        await interaction.reply({ content: `Successfully Executed\n${text}`, ephemeral: true });
    },
};