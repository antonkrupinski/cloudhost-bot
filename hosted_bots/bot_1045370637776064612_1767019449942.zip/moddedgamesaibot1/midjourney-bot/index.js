const { Client, Collection, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ActivityType } = require('discord.js');

// Load config with environment variables fallback
const config = {
    TOKEN: process.env.TOKEN,
    CLIENTID: process.env.CLIENTID
};

if (!config.TOKEN || !config.CLIENTID) {
    console.error('Missing required environment variables: TOKEN and CLIENTID');
    process.exit(1);
}

const client = new Client({
    intents: ["Guilds", "GuildMessages", "MessageContent"]
});

client.slashCommands = new Collection();
client.config = config;

client.once('ready', async () => {
    console.log(`Bot is online as ${client.user.tag}`);

    const channel = client.channels.cache.get('1448670892484988968');
    if (channel) {
        const embed = new EmbedBuilder()
            .setTitle('Modded Games Support')
            .setDescription('In need of assistance? Select an option from the menu below to create a support ticket.')
            .setFields(
                { name: 'Support', value: 'A question or needs to ask a staff member a question.' }
            )
            .setImage('https://media.discordapp.net/attachments/1451955736480579678/1452484503409786931/3A28573E-819B-4EBD-B24C-A8F85822CDCE.png?ex=694e985b&is=694d46db&hm=7c4837367ec362adb0247ec3bcae2b5a028dc72b70c110544b43249f8d428bee&=&format=webp&quality=lossless&width=525&height=350')
            .setThumbnail('https://media.discordapp.net/attachments/1453837466774667447/1453926442143584326/0dPpsMAAAAGSURBVAMA2ZXGPkonigUAAAAASUVORK5CYII.png?ex=694f3a04&is=694de884&hm=87c08a521cd860e6977aa0184576681511aa32b493449767e08c553c81384fb2&=&format=webp&quality=lossless')
            .setColor(0x2f6070)
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('support_select')
                    .setPlaceholder('Select an option')
                    .addOptions([
                        {
                            label: 'Support',
                            description: 'Get Assistance From Our Support Team',
                            value: 'support',
                        },
                    ]),
            );

        await channel.send({ embeds: [embed], components: [row] });
    } else {
        console.log('Channel not found');
    }

    // Set bot status
    const memberCount = client.guilds.cache.reduce((a, b) => a + b.memberCount, 0);
    client.user.setPresence({
        activities: [{ name: `Watching ${memberCount} members`, type: ActivityType.Playing }],
        status: 'online'
    });
});

// Load handlers
require('./src/handlers/event')(client);
require('./src/handlers/slash')(client);

client.login(config.TOKEN);
